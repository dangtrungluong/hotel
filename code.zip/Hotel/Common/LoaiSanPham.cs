﻿using System;

namespace Hotel.Common
{
	// Token: 0x02000022 RID: 34
	public class LoaiSanPham
	{
		// Token: 0x17000013 RID: 19
		// (get) Token: 0x060001FA RID: 506 RVA: 0x00034647 File Offset: 0x00032847
		// (set) Token: 0x060001FB RID: 507 RVA: 0x0003464F File Offset: 0x0003284F
		public string strTenLoaiSanPham { get; set; }

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x060001FC RID: 508 RVA: 0x00034658 File Offset: 0x00032858
		// (set) Token: 0x060001FD RID: 509 RVA: 0x00034660 File Offset: 0x00032860
		public string strGhiChu { get; set; }
	}
}
