﻿using System;
using System.Collections.Generic;

namespace Hotel.Common
{
	// Token: 0x0200002E RID: 46
	public class RoomArea
	{
		// Token: 0x17000055 RID: 85
		// (get) Token: 0x0600028A RID: 650 RVA: 0x00034AA9 File Offset: 0x00032CA9
		// (set) Token: 0x0600028B RID: 651 RVA: 0x00034AB1 File Offset: 0x00032CB1
		public List<List<string>> lstRoom { get; set; }
	}
}
