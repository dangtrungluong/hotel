﻿using System;

namespace Hotel.Common
{
	// Token: 0x02000029 RID: 41
	public class BangGiaNgayDem
	{
		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000259 RID: 601 RVA: 0x00034933 File Offset: 0x00032B33
		// (set) Token: 0x0600025A RID: 602 RVA: 0x0003493B File Offset: 0x00032B3B
		public int iTreToiDa { get; set; }

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x0600025B RID: 603 RVA: 0x00034944 File Offset: 0x00032B44
		// (set) Token: 0x0600025C RID: 604 RVA: 0x0003494C File Offset: 0x00032B4C
		public int iTraPhongTruoc { get; set; }

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x0600025D RID: 605 RVA: 0x00034955 File Offset: 0x00032B55
		// (set) Token: 0x0600025E RID: 606 RVA: 0x0003495D File Offset: 0x00032B5D
		public bool bTinhLa1Ngay { get; set; }

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x0600025F RID: 607 RVA: 0x00034966 File Offset: 0x00032B66
		// (set) Token: 0x06000260 RID: 608 RVA: 0x0003496E File Offset: 0x00032B6E
		public int iQuaGio { get; set; }

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000261 RID: 609 RVA: 0x00034977 File Offset: 0x00032B77
		// (set) Token: 0x06000262 RID: 610 RVA: 0x0003497F File Offset: 0x00032B7F
		public bool bRaSauGioTraPhong { get; set; }
	}
}
