﻿using System;

namespace Hotel.Common
{
	// Token: 0x02000024 RID: 36
	public class MatHang
	{
		// Token: 0x17000018 RID: 24
		// (get) Token: 0x06000206 RID: 518 RVA: 0x0003469C File Offset: 0x0003289C
		// (set) Token: 0x06000207 RID: 519 RVA: 0x000346A4 File Offset: 0x000328A4
		public int iNo { get; set; }

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000208 RID: 520 RVA: 0x000346AD File Offset: 0x000328AD
		// (set) Token: 0x06000209 RID: 521 RVA: 0x000346B5 File Offset: 0x000328B5
		public string strMaSanPham { get; set; }

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x0600020A RID: 522 RVA: 0x000346BE File Offset: 0x000328BE
		// (set) Token: 0x0600020B RID: 523 RVA: 0x000346C6 File Offset: 0x000328C6
		public string strTenSanPham { get; set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x0600020C RID: 524 RVA: 0x000346CF File Offset: 0x000328CF
		// (set) Token: 0x0600020D RID: 525 RVA: 0x000346D7 File Offset: 0x000328D7
		public ulong iGiaMua { get; set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x0600020E RID: 526 RVA: 0x000346E0 File Offset: 0x000328E0
		// (set) Token: 0x0600020F RID: 527 RVA: 0x000346E8 File Offset: 0x000328E8
		public string strDVTMua { get; set; }

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x06000210 RID: 528 RVA: 0x000346F1 File Offset: 0x000328F1
		// (set) Token: 0x06000211 RID: 529 RVA: 0x000346F9 File Offset: 0x000328F9
		public ulong iGiaBan { get; set; }

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000212 RID: 530 RVA: 0x00034702 File Offset: 0x00032902
		// (set) Token: 0x06000213 RID: 531 RVA: 0x0003470A File Offset: 0x0003290A
		public string strDVTBan { get; set; }

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x06000214 RID: 532 RVA: 0x00034713 File Offset: 0x00032913
		// (set) Token: 0x06000215 RID: 533 RVA: 0x0003471B File Offset: 0x0003291B
		public string strNhomMatHang { get; set; }

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000216 RID: 534 RVA: 0x00034724 File Offset: 0x00032924
		// (set) Token: 0x06000217 RID: 535 RVA: 0x0003472C File Offset: 0x0003292C
		public string strLoaiSanPham { get; set; }

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000218 RID: 536 RVA: 0x00034735 File Offset: 0x00032935
		// (set) Token: 0x06000219 RID: 537 RVA: 0x0003473D File Offset: 0x0003293D
		public int iQuyDoi { get; set; }
	}
}
