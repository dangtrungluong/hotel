﻿using System;

namespace Hotel.Common
{
	// Token: 0x02000021 RID: 33
	public class StructDataCommon
	{
	}
}
