﻿using System;

namespace Hotel.Common
{
	// Token: 0x0200002F RID: 47
	public class NhomKhachHang
	{
		// Token: 0x17000056 RID: 86
		// (get) Token: 0x0600028D RID: 653 RVA: 0x00034ABA File Offset: 0x00032CBA
		// (set) Token: 0x0600028E RID: 654 RVA: 0x00034AC2 File Offset: 0x00032CC2
		public int iNo { get; set; }

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x0600028F RID: 655 RVA: 0x00034ACB File Offset: 0x00032CCB
		// (set) Token: 0x06000290 RID: 656 RVA: 0x00034AD3 File Offset: 0x00032CD3
		public string strTenNhomKhachHang { get; set; }

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000291 RID: 657 RVA: 0x00034ADC File Offset: 0x00032CDC
		// (set) Token: 0x06000292 RID: 658 RVA: 0x00034AE4 File Offset: 0x00032CE4
		public int iDiemTichLuy { get; set; }

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000293 RID: 659 RVA: 0x00034AED File Offset: 0x00032CED
		// (set) Token: 0x06000294 RID: 660 RVA: 0x00034AF5 File Offset: 0x00032CF5
		public int iGiamTienHang { get; set; }

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000295 RID: 661 RVA: 0x00034AFE File Offset: 0x00032CFE
		// (set) Token: 0x06000296 RID: 662 RVA: 0x00034B06 File Offset: 0x00032D06
		public int iGiamTienGio { get; set; }

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x06000297 RID: 663 RVA: 0x00034B0F File Offset: 0x00032D0F
		// (set) Token: 0x06000298 RID: 664 RVA: 0x00034B17 File Offset: 0x00032D17
		public int iGiamDoAn { get; set; }

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x06000299 RID: 665 RVA: 0x00034B20 File Offset: 0x00032D20
		// (set) Token: 0x0600029A RID: 666 RVA: 0x00034B28 File Offset: 0x00032D28
		public int iGiamDoUong { get; set; }

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x0600029B RID: 667 RVA: 0x00034B31 File Offset: 0x00032D31
		// (set) Token: 0x0600029C RID: 668 RVA: 0x00034B39 File Offset: 0x00032D39
		public int iGiamDichVu { get; set; }

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x0600029D RID: 669 RVA: 0x00034B42 File Offset: 0x00032D42
		// (set) Token: 0x0600029E RID: 670 RVA: 0x00034B4A File Offset: 0x00032D4A
		public int iGiamDoKhac { get; set; }
	}
}
