﻿using System;

namespace Hotel.Common
{
	// Token: 0x02000027 RID: 39
	public class BangGiaGio
	{
		// Token: 0x17000035 RID: 53
		// (get) Token: 0x06000243 RID: 579 RVA: 0x00034889 File Offset: 0x00032A89
		// (set) Token: 0x06000244 RID: 580 RVA: 0x00034891 File Offset: 0x00032A91
		public int iTreToiDa { get; set; }

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000245 RID: 581 RVA: 0x0003489A File Offset: 0x00032A9A
		// (set) Token: 0x06000246 RID: 582 RVA: 0x000348A2 File Offset: 0x00032AA2
		public bool bGiaNgayThuong { get; set; }

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000247 RID: 583 RVA: 0x000348AB File Offset: 0x00032AAB
		// (set) Token: 0x06000248 RID: 584 RVA: 0x000348B3 File Offset: 0x00032AB3
		public bool bGiaCuoiTuan { get; set; }

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000249 RID: 585 RVA: 0x000348BC File Offset: 0x00032ABC
		// (set) Token: 0x0600024A RID: 586 RVA: 0x000348C4 File Offset: 0x00032AC4
		public bool bGiaNgayLe { get; set; }
	}
}
