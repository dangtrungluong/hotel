﻿using System;

namespace Hotel.Common
{
	// Token: 0x0200002B RID: 43
	public class Table
	{
		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000271 RID: 625 RVA: 0x000349EE File Offset: 0x00032BEE
		// (set) Token: 0x06000272 RID: 626 RVA: 0x000349F6 File Offset: 0x00032BF6
		public int iNo { get; set; }

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000273 RID: 627 RVA: 0x000349FF File Offset: 0x00032BFF
		// (set) Token: 0x06000274 RID: 628 RVA: 0x00034A07 File Offset: 0x00032C07
		public string strTenBan { get; set; }

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000275 RID: 629 RVA: 0x00034A10 File Offset: 0x00032C10
		// (set) Token: 0x06000276 RID: 630 RVA: 0x00034A18 File Offset: 0x00032C18
		public ulong iTienMoBan { get; set; }

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000277 RID: 631 RVA: 0x00034A21 File Offset: 0x00032C21
		// (set) Token: 0x06000278 RID: 632 RVA: 0x00034A29 File Offset: 0x00032C29
		public string strKhuVuc { get; set; }

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000279 RID: 633 RVA: 0x00034A32 File Offset: 0x00032C32
		// (set) Token: 0x0600027A RID: 634 RVA: 0x00034A3A File Offset: 0x00032C3A
		public string strNhomHienThi { get; set; }

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x0600027B RID: 635 RVA: 0x00034A43 File Offset: 0x00032C43
		// (set) Token: 0x0600027C RID: 636 RVA: 0x00034A4B File Offset: 0x00032C4B
		public string strLoaiPhong { get; set; }

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x0600027D RID: 637 RVA: 0x00034A54 File Offset: 0x00032C54
		// (set) Token: 0x0600027E RID: 638 RVA: 0x00034A5C File Offset: 0x00032C5C
		public string strGhiChu { get; set; }
	}
}
