﻿using System;

namespace Hotel.Common
{
	// Token: 0x02000023 RID: 35
	public class NhomMatHang
	{
		// Token: 0x17000015 RID: 21
		// (get) Token: 0x060001FF RID: 511 RVA: 0x00034669 File Offset: 0x00032869
		// (set) Token: 0x06000200 RID: 512 RVA: 0x00034671 File Offset: 0x00032871
		public string strTenNhomMatHang { get; set; }

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x06000201 RID: 513 RVA: 0x0003467A File Offset: 0x0003287A
		// (set) Token: 0x06000202 RID: 514 RVA: 0x00034682 File Offset: 0x00032882
		public string strMaSanPham { get; set; }

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x06000203 RID: 515 RVA: 0x0003468B File Offset: 0x0003288B
		// (set) Token: 0x06000204 RID: 516 RVA: 0x00034693 File Offset: 0x00032893
		public string strLoaiSanPham { get; set; }
	}
}
