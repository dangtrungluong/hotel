﻿using System;

namespace Hotel.Common
{
	// Token: 0x02000025 RID: 37
	public class LoaiPhong
	{
		// Token: 0x17000022 RID: 34
		// (get) Token: 0x0600021B RID: 539 RVA: 0x00034746 File Offset: 0x00032946
		// (set) Token: 0x0600021C RID: 540 RVA: 0x0003474E File Offset: 0x0003294E
		public string strTenLoaiPhong { get; set; }

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x0600021D RID: 541 RVA: 0x00034757 File Offset: 0x00032957
		// (set) Token: 0x0600021E RID: 542 RVA: 0x0003475F File Offset: 0x0003295F
		public int iMauChu { get; set; }

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x0600021F RID: 543 RVA: 0x00034768 File Offset: 0x00032968
		// (set) Token: 0x06000220 RID: 544 RVA: 0x00034770 File Offset: 0x00032970
		public int iMauNen { get; set; }

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000221 RID: 545 RVA: 0x00034779 File Offset: 0x00032979
		// (set) Token: 0x06000222 RID: 546 RVA: 0x00034781 File Offset: 0x00032981
		public string strTenHienThi { get; set; }

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000223 RID: 547 RVA: 0x0003478A File Offset: 0x0003298A
		// (set) Token: 0x06000224 RID: 548 RVA: 0x00034792 File Offset: 0x00032992
		public string strGhiChu { get; set; }
	}
}
