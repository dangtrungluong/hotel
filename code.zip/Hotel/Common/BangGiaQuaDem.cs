﻿using System;

namespace Hotel.Common
{
	// Token: 0x02000028 RID: 40
	public class BangGiaQuaDem
	{
		// Token: 0x17000039 RID: 57
		// (get) Token: 0x0600024C RID: 588 RVA: 0x000348CD File Offset: 0x00032ACD
		// (set) Token: 0x0600024D RID: 589 RVA: 0x000348D5 File Offset: 0x00032AD5
		public int iTreToiDa { get; set; }

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x0600024E RID: 590 RVA: 0x000348DE File Offset: 0x00032ADE
		// (set) Token: 0x0600024F RID: 591 RVA: 0x000348E6 File Offset: 0x00032AE6
		public int iTraPhongTruoc { get; set; }

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000250 RID: 592 RVA: 0x000348EF File Offset: 0x00032AEF
		// (set) Token: 0x06000251 RID: 593 RVA: 0x000348F7 File Offset: 0x00032AF7
		public int iGioVaoSau1 { get; set; }

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000252 RID: 594 RVA: 0x00034900 File Offset: 0x00032B00
		// (set) Token: 0x06000253 RID: 595 RVA: 0x00034908 File Offset: 0x00032B08
		public int iQuaGio { get; set; }

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000254 RID: 596 RVA: 0x00034911 File Offset: 0x00032B11
		// (set) Token: 0x06000255 RID: 597 RVA: 0x00034919 File Offset: 0x00032B19
		public int iGioVaoSau2 { get; set; }

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000256 RID: 598 RVA: 0x00034922 File Offset: 0x00032B22
		// (set) Token: 0x06000257 RID: 599 RVA: 0x0003492A File Offset: 0x00032B2A
		public int iTruocGio { get; set; }
	}
}
