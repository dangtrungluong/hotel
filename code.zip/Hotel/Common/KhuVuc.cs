﻿using System;

namespace Hotel.Common
{
	// Token: 0x0200002A RID: 42
	public class KhuVuc
	{
		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000264 RID: 612 RVA: 0x00034988 File Offset: 0x00032B88
		// (set) Token: 0x06000265 RID: 613 RVA: 0x00034990 File Offset: 0x00032B90
		public int iNo { get; set; }

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000266 RID: 614 RVA: 0x00034999 File Offset: 0x00032B99
		// (set) Token: 0x06000267 RID: 615 RVA: 0x000349A1 File Offset: 0x00032BA1
		public string strTenKhuVuc { get; set; }

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000268 RID: 616 RVA: 0x000349AA File Offset: 0x00032BAA
		// (set) Token: 0x06000269 RID: 617 RVA: 0x000349B2 File Offset: 0x00032BB2
		public string strGiaMatHang { get; set; }

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x0600026A RID: 618 RVA: 0x000349BB File Offset: 0x00032BBB
		// (set) Token: 0x0600026B RID: 619 RVA: 0x000349C3 File Offset: 0x00032BC3
		public string strKhoHang { get; set; }

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x0600026C RID: 620 RVA: 0x000349CC File Offset: 0x00032BCC
		// (set) Token: 0x0600026D RID: 621 RVA: 0x000349D4 File Offset: 0x00032BD4
		public string strMauHoaDon { get; set; }

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x0600026E RID: 622 RVA: 0x000349DD File Offset: 0x00032BDD
		// (set) Token: 0x0600026F RID: 623 RVA: 0x000349E5 File Offset: 0x00032BE5
		public string strGhiChu { get; set; }
	}
}
