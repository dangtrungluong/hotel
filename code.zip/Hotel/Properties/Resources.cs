﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Hotel.Properties
{
	// Token: 0x02000019 RID: 25
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x060001B9 RID: 441 RVA: 0x0003200C File Offset: 0x0003020C
		internal Resources()
		{
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x060001BA RID: 442 RVA: 0x00032018 File Offset: 0x00030218
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				bool flag = Resources.resourceMan == null;
				if (flag)
				{
					ResourceManager resourceManager = new ResourceManager("Hotel.Properties.Resources", typeof(Resources).Assembly);
					Resources.resourceMan = resourceManager;
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x060001BB RID: 443 RVA: 0x00032060 File Offset: 0x00030260
		// (set) Token: 0x060001BC RID: 444 RVA: 0x00032077 File Offset: 0x00030277
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x060001BD RID: 445 RVA: 0x00032080 File Offset: 0x00030280
		internal static Bitmap banggiadichvu
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("banggiadichvu", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x060001BE RID: 446 RVA: 0x000320B0 File Offset: 0x000302B0
		internal static Bitmap Banner
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Banner", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x060001BF RID: 447 RVA: 0x000320E0 File Offset: 0x000302E0
		internal static Bitmap beer
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("beer", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x060001C0 RID: 448 RVA: 0x00032110 File Offset: 0x00030310
		internal static Bitmap coffee_off
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("coffee_off", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x060001C1 RID: 449 RVA: 0x00032140 File Offset: 0x00030340
		internal static Bitmap coffee_off1
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("coffee_off1", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x060001C2 RID: 450 RVA: 0x00032170 File Offset: 0x00030370
		internal static Bitmap Edit
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Edit", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x060001C3 RID: 451 RVA: 0x000321A0 File Offset: 0x000303A0
		internal static Bitmap hotel
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("hotel", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x060001C4 RID: 452 RVA: 0x000321D0 File Offset: 0x000303D0
		internal static Bitmap Logo
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Logo", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x060001C5 RID: 453 RVA: 0x00032200 File Offset: 0x00030400
		internal static Bitmap roomlock
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("roomlock", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x060001C6 RID: 454 RVA: 0x00032230 File Offset: 0x00030430
		internal static Bitmap table3
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("table3", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x060001C7 RID: 455 RVA: 0x00032260 File Offset: 0x00030460
		internal static Bitmap wizard
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("wizard", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x04000369 RID: 873
		private static ResourceManager resourceMan;

		// Token: 0x0400036A RID: 874
		private static CultureInfo resourceCulture;
	}
}
