﻿using System;

namespace Hotel.Json
{
	// Token: 0x0200001D RID: 29
	public class SaveConfigLogin
	{
		// Token: 0x17000011 RID: 17
		// (get) Token: 0x060001D1 RID: 465 RVA: 0x000322F1 File Offset: 0x000304F1
		// (set) Token: 0x060001D2 RID: 466 RVA: 0x000322F9 File Offset: 0x000304F9
		public bool bRemember { get; set; }

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x060001D3 RID: 467 RVA: 0x00032302 File Offset: 0x00030502
		// (set) Token: 0x060001D4 RID: 468 RVA: 0x0003230A File Offset: 0x0003050A
		public bool bAutoLog { get; set; }
	}
}
