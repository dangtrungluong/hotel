﻿using System;

namespace Hotel.Json
{
	// Token: 0x0200001B RID: 27
	public class WriteData2Json
	{
	}
}
