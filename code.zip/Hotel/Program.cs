﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using Hotel.Common;
using Hotel.Json;
using Newtonsoft.Json;

namespace Hotel
{
	// Token: 0x02000017 RID: 23
	internal static class Program
	{
		// Token: 0x060001AC RID: 428 RVA: 0x00030468 File Offset: 0x0002E668
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			FunctionCommon functionCommon = new FunctionCommon();
			List<AddNewAccount> list = new List<AddNewAccount>();
			SaveConfigLogin saveConfigLogin = new SaveConfigLogin();
			bool flag = !Directory.Exists(CMConstant.strFolderConfigure);
			if (flag)
			{
				try
				{
					Directory.CreateDirectory(CMConstant.strFolderConfigure);
				}
				catch (Exception ex)
				{
					functionCommon.Msg(ex.Message, "Lỗi");
					return;
				}
			}
			bool flag2 = !Directory.Exists(CMConstant.strFolderData);
			if (flag2)
			{
				try
				{
					Directory.CreateDirectory(CMConstant.strFolderData);
				}
				catch (Exception ex2)
				{
					functionCommon.Msg(ex2.Message, "Lỗi");
					return;
				}
			}
			string path = Path.Combine(CMConstant.strFolderPath, "ConfigFile\\ConfigLogin.json");
			bool flag3 = File.Exists(path);
			if (flag3)
			{
				string value = File.ReadAllText(path);
				saveConfigLogin = (JsonConvert.DeserializeObject<SaveConfigLogin>(value) ?? new SaveConfigLogin());
			}
			try
			{
				bool bAutoLog = saveConfigLogin.bAutoLog;
				if (bAutoLog)
				{
					string text = string.Empty;
					string text2 = string.Empty;
					string text3 = Path.Combine(CMConstant.strFolderPath, "Data\\RememberAccount.bin");
					string text4 = Path.Combine(CMConstant.strFolderPath, "Data\\Account.bin");
					bool flag4 = File.Exists(text3);
					if (flag4)
					{
						List<AddNewAccount> list2 = functionCommon.ReadFromBinaryFile<List<AddNewAccount>>(text3);
						bool flag5 = list2.Count > 0;
						if (flag5)
						{
							text = functionCommon.Base64Decode(list2[0].strUserName);
							text2 = functionCommon.Base64Decode(list2[0].strPassWord);
						}
					}
					bool flag6 = File.Exists(text4);
					if (flag6)
					{
						list = functionCommon.ReadFromBinaryFile<List<AddNewAccount>>(text4);
						foreach (AddNewAccount addNewAccount in list)
						{
							bool flag7 = text.Equals(functionCommon.Base64Decode(addNewAccount.strUserName)) && text2.Equals(functionCommon.Base64Decode(addNewAccount.strPassWord));
							if (flag7)
							{
								Application.Run(new frmMain());
								return;
							}
						}
					}
				}
				Application.Run(new frmLogin());
			}
			catch (Exception ex3)
			{
				functionCommon.Msg(ex3.Message, "Lỗi");
			}
		}
	}
}
